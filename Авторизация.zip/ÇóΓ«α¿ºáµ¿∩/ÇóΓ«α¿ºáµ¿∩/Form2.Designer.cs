﻿namespace Авторизация
{
    partial class RegMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BackgroundText = new System.Windows.Forms.Label();
            this.LbLogin = new System.Windows.Forms.Label();
            this.LbPassword = new System.Windows.Forms.Label();
            this.TbLogin = new System.Windows.Forms.TextBox();
            this.TbPassword = new System.Windows.Forms.TextBox();
            this.ButRegTwo = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // BackgroundText
            // 
            this.BackgroundText.AutoSize = true;
            this.BackgroundText.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BackgroundText.Location = new System.Drawing.Point(39, 9);
            this.BackgroundText.Name = "BackgroundText";
            this.BackgroundText.Size = new System.Drawing.Size(175, 29);
            this.BackgroundText.TabIndex = 0;
            this.BackgroundText.Text = "Регистрация";
            // 
            // LbLogin
            // 
            this.LbLogin.AutoSize = true;
            this.LbLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbLogin.Location = new System.Drawing.Point(7, 71);
            this.LbLogin.Name = "LbLogin";
            this.LbLogin.Size = new System.Drawing.Size(47, 16);
            this.LbLogin.TabIndex = 1;
            this.LbLogin.Text = "Логин";
            // 
            // LbPassword
            // 
            this.LbPassword.AutoSize = true;
            this.LbPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbPassword.Location = new System.Drawing.Point(7, 111);
            this.LbPassword.Name = "LbPassword";
            this.LbPassword.Size = new System.Drawing.Size(57, 16);
            this.LbPassword.TabIndex = 2;
            this.LbPassword.Text = "Пароль";
            // 
            // TbLogin
            // 
            this.TbLogin.Location = new System.Drawing.Point(70, 71);
            this.TbLogin.Name = "TbLogin";
            this.TbLogin.Size = new System.Drawing.Size(106, 20);
            this.TbLogin.TabIndex = 3;
            // 
            // TbPassword
            // 
            this.TbPassword.Location = new System.Drawing.Point(70, 112);
            this.TbPassword.Name = "TbPassword";
            this.TbPassword.Size = new System.Drawing.Size(106, 20);
            this.TbPassword.TabIndex = 4;
            this.toolTip1.SetToolTip(this.TbPassword, "Пароль дожен содержать:\r\n1.Заглавную букву \r\n2.Один из знаков(!@#$%^)\r\n3.Больше ш" +
        "ести знаков\r\n4.Цифру ");
            // 
            // ButRegTwo
            // 
            this.ButRegTwo.BackColor = System.Drawing.Color.White;
            this.ButRegTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ButRegTwo.Location = new System.Drawing.Point(12, 151);
            this.ButRegTwo.Name = "ButRegTwo";
            this.ButRegTwo.Size = new System.Drawing.Size(208, 56);
            this.ButRegTwo.TabIndex = 6;
            this.ButRegTwo.Text = "Сохранить и зарегистрироваться";
            this.ButRegTwo.UseVisualStyleBackColor = false;
            this.ButRegTwo.Click += new System.EventHandler(this.ButRegTwo_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Подсказка";
            // 
            // RegMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(235, 220);
            this.Controls.Add(this.ButRegTwo);
            this.Controls.Add(this.TbPassword);
            this.Controls.Add(this.TbLogin);
            this.Controls.Add(this.LbPassword);
            this.Controls.Add(this.LbLogin);
            this.Controls.Add(this.BackgroundText);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "RegMenu";
            this.Text = "Регистрация";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label BackgroundText;
        private System.Windows.Forms.Label LbLogin;
        private System.Windows.Forms.Label LbPassword;
        private System.Windows.Forms.TextBox TbLogin;
        private System.Windows.Forms.TextBox TbPassword;
        private System.Windows.Forms.Button ButRegTwo;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}